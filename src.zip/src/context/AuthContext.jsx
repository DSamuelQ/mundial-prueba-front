import { createContext, useContext, useState } from "react";
import { loginUsuario } from "../api/usuarios";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("user");
    return stored ? JSON.parse(stored) : null;
  });

  const login = async (usuario, password) => {
    console.log("Llamando a loginUsuario API...");
    const res = await loginUsuario({ usuario, password });
    console.log("Respuesta de loginUsuario:", res.data);
    setUser(res.data);
    localStorage.setItem("user", JSON.stringify(res.data));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
