import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Sidebar from "./components/Sidebar";

import Login from "./pages/Login";
import Clientes from "./pages/Clientes";
import Pedidos from "./pages/Pedidos";
import PedidoDetalle from "./pages/PedidoDetalle";
import Users from "./pages/Users";
import Reports from "./pages/Reports";

function AppContent() {
  const { user } = useAuth();
  return (
    <div className="app-root">
      {user && <Sidebar />}
      <main className={`app-main ${user ? "with-sidebar" : ""}`}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<ProtectedRoute><Clientes /></ProtectedRoute>} />
          <Route path="/usuarios" element={<ProtectedRoute>{user?.rol?.nombreRol === "admin" && <Users />}</ProtectedRoute>} />
          <Route path="/pedidos" element={<ProtectedRoute><Pedidos /></ProtectedRoute>} />
          <Route path="/pedidos/:id" element={<ProtectedRoute><PedidoDetalle /></ProtectedRoute>} />
          <Route path="/reportes" element={<ProtectedRoute>{user?.rol?.nombreRol === "admin" && <Reports />}</ProtectedRoute>} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </AuthProvider>
  );
}
