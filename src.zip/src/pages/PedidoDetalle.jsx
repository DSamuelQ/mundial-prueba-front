import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import api from "../api/axiosConfig";
import PedidoMapa from "../components/PedidoMapa";

export default function PedidoDetalle() {
  const { id } = useParams();
  const [pedido, setPedido] = useState(null);

  useEffect(() => {
    api.get(`/pedidos/${id}`).then(res => setPedido(res.data));
  }, [id]);

  if (!pedido) return <div>Cargando...</div>;

  return (
    <div className="p-6">
      <h1 className="text-xl mb-4">Pedido #{pedido.id_pedido}</h1>
      <p><b>Cliente:</b> {pedido.nombre} {pedido.apellido}</p>
      <p><b>Teléfono:</b> {pedido.telefono}</p>
      <p><b>Total:</b> Q{pedido.total}</p>

      <h2 className="text-lg mt-4">Detalles</h2>
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>Producto</th><th>Cantidad</th><th>Precio</th>
          </tr>
        </thead>
        <tbody>
          {pedido.detalles.map((d, i) => (
            <tr key={i}>
              <td>{d.nombre_producto}</td>
              <td>{d.cantidad}</td>
              <td>Q{d.precio_unitario}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {pedido.latitud && pedido.longitud && (
        <PedidoMapa lat={Number(pedido.latitud)} lng={Number(pedido.longitud)} />
      )}
    </div>
  );
}
