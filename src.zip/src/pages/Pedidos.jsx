import { useEffect, useState } from "react";
import { getPedidos } from "../api/pedidos";
import { useNavigate } from "react-router-dom";
import api from "../api/axiosConfig";

export default function Pedidos() {
  const [pedidos, setPedidos] = useState([]);
  const [filtros, setFiltros] = useState({ usuario: "", desde: "", hasta: "" });
  const navigate = useNavigate();

  useEffect(() => {
    getPedidos().then(res => setPedidos(res.data));
  }, []);

  const buscar = async () => {
    const params = {};
    if (filtros.usuario) params.usuario = filtros.usuario;
    if (filtros.desde) params.desde = filtros.desde;
    if (filtros.hasta) params.hasta = filtros.hasta;
    const res = await api.get("/pedidos", { params });
    setPedidos(res.data);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl mb-4">Pedidos</h1>
      <div className="mb-4">
        <input placeholder="Usuario" value={filtros.usuario} onChange={e => setFiltros({ ...filtros, usuario: e.target.value })} className="border p-2 mr-2" />
        <input type="date" value={filtros.desde} onChange={e => setFiltros({ ...filtros, desde: e.target.value })} className="border p-2 mr-2" />
        <input type="date" value={filtros.hasta} onChange={e => setFiltros({ ...filtros, hasta: e.target.value })} className="border p-2 mr-2" />
        <button onClick={buscar} className="bg-blue-500 text-white p-2">Filtrar</button>
      </div>
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>ID</th><th>Cliente</th><th>Fecha</th><th>Total</th>
          </tr>
        </thead>
        <tbody>
          {pedidos.map(p => (
            <tr key={p.id_pedido} className="cursor-pointer hover:bg-gray-100"
              onClick={() => navigate(`/pedidos/${p.id_pedido}`)}>
              <td>{p.id_pedido}</td>
              <td>{p.nombre} {p.apellido}</td>
              <td>{new Date(p.fecha_pedido).toLocaleString()}</td>
              <td>Q{p.total}</td>
              <td>
                {p.latitud && p.longitud
                  ? <a href={`https://maps.google.com/?q=${p.latitud},${p.longitud}`} target="_blank" rel="noopener noreferrer">Ver mapa</a>
                  : "No disponible"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
