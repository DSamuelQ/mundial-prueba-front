import { useEffect, useState } from "react";
import { getClientes, createCliente } from "../api/clientes";

export default function Clientes() {
  const [clientes, setClientes] = useState([]);
  const [form, setForm] = useState({ nombre: "", apellido: "", telefono: "" });

  useEffect(() => {
    getClientes().then(res => setClientes(res.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createCliente(form);
    const res = await getClientes();
    setClientes(res.data);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl mb-4">Clientes</h1>
      <form onSubmit={handleSubmit} className="mb-4 flex gap-2">
        <input type="text" placeholder="Nombre" value={form.nombre}
          onChange={e => setForm({ ...form, nombre: e.target.value })} />
        <input type="text" placeholder="Apellido" value={form.apellido}
          onChange={e => setForm({ ...form, apellido: e.target.value })} />
        <input type="text" placeholder="Teléfono" value={form.telefono}
          onChange={e => setForm({ ...form, telefono: e.target.value })} />
        <button className="bg-blue-500 text-white px-3">Agregar</button>
      </form>

      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>ID</th><th>Nombre</th><th>Apellido</th><th>Teléfono</th>
          </tr>
        </thead>
        <tbody>
          {clientes.map(c => (
            <tr key={c.id_cliente}>
              <td>{c.id_cliente}</td>
              <td>{c.nombre}</td>
              <td>{c.apellido}</td>
              <td>{c.telefono}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
