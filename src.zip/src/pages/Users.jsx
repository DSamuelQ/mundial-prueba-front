import { useEffect, useState } from "react";
import { getUsuarios, registrarUsuario, updateUsuario, deleteUsuario } from "../api/usuarios";
import { useAuth } from "../context/AuthContext";

export default function Users() {
  const [usuarios, setUsuarios] = useState([]);
  const [nuevo, setNuevo] = useState({ nombre: "", apellido: "", usuario: "", password: "", rol: "" });
  const [editando, setEditando] = useState(null);
  const [editData, setEditData] = useState({});
  const { user } = useAuth();

  useEffect(() => {
    cargarUsuarios();
  }, []);

  const cargarUsuarios = async () => {
    const res = await getUsuarios();
    setUsuarios(res.data);
  };

  const crearUsuario = async () => {
    await registrarUsuario(nuevo);
    setNuevo({ nombre: "", apellido: "", usuario: "", password: "", rol: "" });
    cargarUsuarios();
  };

  const eliminarUsuarioHandler = async (id) => {
    await deleteUsuario(id);
    cargarUsuarios();
  };

  const iniciarEdicion = (usuario) => {
    setEditando(usuario.id_usuario);
    setEditData(usuario);
  };

  const guardarEdicion = async () => {
    await updateUsuario(editando, editData);
    setEditando(null);
    cargarUsuarios();
  };

  return (
    <div className="p-6">
      <h1 className="text-xl mb-4">Gestión de Usuarios</h1>
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>Nombre</th><th>Apellido</th><th>Usuario</th><th>Rol</th><th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {usuarios.map(u => (
            <tr key={u.id_usuario} className="border-b">
              <td>
                {editando === u.id_usuario
                  ? <input value={editData.nombre} onChange={e => setEditData({ ...editData, nombre: e.target.value })} />
                  : u.nombre}
              </td>
              <td>
                {editando === u.id_usuario
                  ? <input value={editData.apellido} onChange={e => setEditData({ ...editData, apellido: e.target.value })} />
                  : u.apellido}
              </td>
              <td>{u.usuario}</td>
              <td>
                {editando === u.id_usuario
                  ? <input value={editData.rol} onChange={e => setEditData({ ...editData, rol: e.target.value })} />
                  : (u.rol && u.rol.nombreRol ? u.rol.nombreRol : u.rol)}
              </td>
              <td>
                {editando === u.id_usuario ? (
                  <>
                    <button onClick={guardarEdicion}>Guardar</button>
                    <button onClick={() => setEditando(null)}>Cancelar</button>
                  </>
                ) : (
                  <>
                    <button onClick={() => iniciarEdicion(u)}>Editar</button>
                    <button onClick={() => eliminarUsuarioHandler(u.id_usuario)}>Eliminar</button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <h3 className="text-lg mt-4">Crear usuario</h3>
      <div className="grid grid-cols-2 gap-4">
        <input className="border p-2" placeholder="Nombre" value={nuevo.nombre} onChange={e => setNuevo({ ...nuevo, nombre: e.target.value })} />
        <input className="border p-2" placeholder="Apellido" value={nuevo.apellido} onChange={e => setNuevo({ ...nuevo, apellido: e.target.value })} />
        <input className="border p-2" placeholder="Usuario" value={nuevo.usuario} onChange={e => setNuevo({ ...nuevo, usuario: e.target.value })} />
        <input className="border p-2" placeholder="Password" type="password" value={nuevo.password} onChange={e => setNuevo({ ...nuevo, password: e.target.value })} />
        <input className="border p-2" placeholder="Rol" value={nuevo.rol} onChange={e => setNuevo({ ...nuevo, rol: e.target.value })} />
        <button className="bg-blue-500 text-white p-2" onClick={crearUsuario}>Crear</button>
      </div>
    </div>
  );
}
