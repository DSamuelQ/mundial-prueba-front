import { useEffect, useState } from "react";
import axios from "axios";

export default function Reports() {
  const [report, setReport] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/reports/general").then(res => setReport(res.data));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-xl mb-4">Reporte General</h1>
      <ul>
        {report.map(r => (
          <li key={r.userId}>
            Usuario {r.userName} → {r.totalPedidos} pedidos
          </li>
        ))}
      </ul>
    </div>
  );
}
