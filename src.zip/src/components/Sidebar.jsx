import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <aside className="d-flex flex-column bg-info vh-100 text-dark" style={{ width: 240 }}>
      <div className="p-3 border-bottom">
        <div className="h5 fw-bold">ClientesPedidos</div>
      </div>

      <nav className="nav flex-column p-2 gap-2">
        <Link to="/pedidos" className="nav-link rounded px-3 text-dark">📦 Pedidos</Link>
        <Link to="/" className="nav-link rounded px-3 text-dark">👥 Clientes</Link>
        {user?.rol?.nombreRol === "admin" && (
          <>
            <Link to="/usuarios" className="nav-link rounded px-3 text-dark">🧑‍💼 Usuarios</Link>
            <Link to="/reportes" className="nav-link rounded px-3 text-dark">📊 Reportes</Link>
          </>
        )}
      </nav>

      <div className="mt-auto p-3 border-top">
        <div className="mb-2 small">👤 {user.nombre} <span className="text-muted">({user.rol?.nombreRol})</span></div>
        <button className="btn btn-dark w-100" onClick={handleLogout}>Cerrar sesión</button>
      </div>
    </aside>
  );
}