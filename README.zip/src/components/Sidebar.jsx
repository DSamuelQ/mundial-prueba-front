import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <aside
      className="fixed top-0 left-0 h-full w-56 bg-cyan-600 text-white flex flex-col justify-between shadow-lg"
      style={{ zIndex: 100 }}
    >
      <div>
        <div className="px-6 py-5 text-xl font-bold border-b border-cyan-500 mb-4">
          <span>ClientesPedidos</span>
        </div>
        <nav className="flex flex-col gap-2 px-4">
          <Link to="/" className="hover:bg-cyan-700 rounded px-3 py-2">Clientes</Link>
          <Link to="/pedidos" className="hover:bg-cyan-700 rounded px-3 py-2">Pedidos</Link>
          {user.rol && user.rol.nombreRol === "admin" && (
            <>
              <Link to="/usuarios" className="hover:bg-cyan-700 rounded px-3 py-2">Usuarios</Link>
              <Link to="/reportes" className="hover:bg-cyan-700 rounded px-3 py-2">Reportes</Link>
            </>
          )}
        </nav>
      </div>
      <div className="px-6 py-4 border-t border-cyan-500 flex flex-col gap-2">
        <span className="text-sm mb-2">👤 {user.nombre} ({user.rol && user.rol.nombreRol})</span>
        <button
          onClick={handleLogout}
          className="bg-white text-cyan-600 hover:bg-cyan-100 px-3 py-1 rounded"
        >
          Cerrar sesión
        </button>
      </div>
    </aside>
  );
}